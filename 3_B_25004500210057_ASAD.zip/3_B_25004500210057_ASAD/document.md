# PTMAE — Project Documentation

**Project name:** Pure Python Transactional Micro-Banking & Audit Engine (PTMAE)  
**Document ID:** PTMAE-SRS-1.0  
**Course:** Python Programming (Units 1–5)  
**Main source file:** `main.py`  
**Python version:** Python 3.x  
**External packages:** None

## 1. Project overview

PTMAE is a command-line banking demonstration written in one Python source file. It demonstrates transaction calculations, manual log parsing, closures and lambdas, reverse indexing, in-place list processing, file validation and logging, custom exceptions, and polymorphic account settlement.

The program is a student project and uses local text files. It is not a production banking system and should not be used to store real financial information.

## 2. Files

- `main.py` — executable program, all five modules, and demonstration code.
- `document.md` — project description, architecture, state/scope notes, compliance checklist, and run instructions.
- `accounts.db` — optional text file created by the user for account records.
- `ledger.txt` — appended audit entries when records are accepted or updated.
- `corrupted.log` — appended descriptions of rejected records.

## 3. How to run

1. Install Python 3.x.
2. Save `main.py` and `document.md` in the same folder.
3. Open a terminal or command prompt in that folder.
4. Run:

   ```bash
   python main.py
   ```

5. The program first runs demonstrations. When asked whether to start the interactive command loop, enter `yes` or `no`.

### Interactive commands

| Command | Purpose |
|---|---|
| `interest` | Calculate compound interest using repeated arithmetic |
| `penalty` | Calculate a percentage penalty and deduct it from the demo balance |
| `balance` | Display the current demo balance |
| `exit` | Exit the command loop |

## 4. Architecture diagram

```text
                         +----------------------+
                         |        main()        |
                         +----------+-----------+
                                    |
                         +----------v-----------+
                         | run_demonstrations() |
                         +----------+-----------+
                                    |
            +-----------------------+-----------------------+
            |                       |                       |
   +--------v---------+   +---------v--------+    +---------v--------+
   | Module 1         |   | Module 2          |    | Module 3         |
   | State / loops    |   | Parser / closures |    | Reverse index /  |
   | arithmetic       |   | lambdas           |    | in-place queue   |
   +------------------+   +-------------------+    +------------------+
            |                       |                       |
            +-----------------------+-----------------------+
                                    |
                         +----------v-----------+
                         | Module 4              |
                         | File validation,      |
                         | database update, logs |
                         +----------+-----------+
                                    |
                         +----------v-----------+
                         | Module 5              |
                         | Account hierarchy and |
                         | polymorphic settlement|
                         +-----------------------+
```

## 5. Module descriptions

### Module 1 — State control engine

- `compound_interest()` calculates compound interest through repeated multiplication and uses no `math` import.
- `calculate_penalty()` calculates a percentage fee using arithmetic operators.
- `trajectory_guard()` processes a transaction sequence and stops when a safety condition or termination flag is met.
- `command_loop()` provides a nested-loop text interface and continues until `exit` is entered.

### Module 2 — Native log parser and closures

- `parse_raw_log_line()` manually scans the string by index. It supports quoted fields, delimiters inside quotes, doubled quote characters, empty fields, and a trailing delimiter.
- `create_audit_filter()` returns a nested function. Its `nonlocal` counter is separate for each filter instance.
- `make_positional_filters()` creates lambdas with default-argument binding (`k=k`) so each lambda retains its own position.

### Module 3 — Reverse index and in-place processing

- `build_reverse_index()` maps each service tag to sorted, unique `(account_id, branch_id)` pairs.
- `clean_transaction_queue()` changes the supplied list rather than binding a replacement top-level list. Tuple entries become lists, sets lose even integer values, embedded lists are sorted descending, and duplicate primitive top-level values are removed while retaining the first occurrence.
- The caller can verify object identity by comparing `id(queue)` before and after the function call.

### Module 4 — File handling and exceptions

Custom exceptions:

- `BaseSystemError`
- `CorruptedRecordError`
- `OutOfBoundsError`
- `InsufficientBalanceError`

`parse_account_record()` validates the expected `ID,TYPE,BALANCE` format. `audit_database()` validates each line independently, appending accepted records to `ledger.txt` and rejected records with line numbers to `corrupted.log`.

`update_account_in_place()` updates a selected record in the existing file and shifts following bytes in chunks if the replacement record length changes. It uses a binary read/write handle for precise byte offsets and to avoid text-mode seek ambiguity. This is an implementation detail worth explaining during evaluation because the specification describes the file conceptually as a text database.

### Module 5 — Object-oriented and polymorphic engine

```text
                      Account
                         |
          +--------------+--------------+
          |              |              |
    SavingsAccount  CurrentAccount  CreditAccount
```

- `Account` contains a private balance (`__balance`), a protected identifier (`_account_id`), public getters/setters, and the class attribute `total_accounts`.
- `SavingsAccount` rejects a transaction that would leave less than 1000.
- `CurrentAccount` permits an overdraft up to its configured private limit.
- `CreditAccount` adds a 2.5% surcharge before applying the transaction against the available credit.
- `execute_batch_settlement()` catches each account's error separately, so a failed settlement does not prevent later accounts from being processed.

## 6. State and scope tracking table

| Name or construct | Scope / visibility | Purpose |
|---|---|---|
| `balance` inside `command_loop()` | Local variable | Stores the interactive demonstration balance |
| `audited_count` inside `create_audit_filter()` | Enclosing local, modified with `nonlocal` | Tracks how many records one filter has checked |
| `k=k` in each lambda | Default argument | Captures the current loop position to prevent late-binding bugs |
| `Account.__balance` | Private by name mangling | Stores account balance internally |
| `Account._account_id` | Protected-by-convention attribute | Stores account identifier |
| `Account.total_accounts` | Class attribute | Counts account objects created |
| `validate.audit_count()` | Function attribute referencing a nested reader | Exposes the closure's audit count without a global variable |

No global variable is used to pass mutable state to the closures.

## 7. Data format

Create `accounts.db` as a UTF-8 text file with one record per line:

```text
Acc101,SAVINGS,5200.00
Acc102,CURRENT,750.00
Acc103,CREDIT,1000.00
```

Each record must contain exactly three fields: account ID, account type (`SAVINGS`, `CURRENT`, or `CREDIT`), and a numeric balance. A malformed record is rejected and logged.

**Warning:** Run file-update demonstrations only on a copy of important data. The sample file is plain text and has no authentication, encryption, or transaction rollback.

## 8. Syllabus compliance checklist

- [x] **Unit 1:** nested loops, conditions, arithmetic calculations, short-circuit guard logic.
- [x] **Unit 2:** functions, manual index-based parsing, closures, `nonlocal`, lambdas, default-argument binding.
- [x] **Unit 3:** dictionary/set/list processing, comprehensions, reverse index, in-place queue changes.
- [x] **Unit 4:** file I/O, exception classes, `try`/`except`/`else`/`finally` patterns, audit logging.
- [x] **Unit 5:** classes, inheritance, `super()`, encapsulation, name mangling, overridden methods, polymorphism.

The source specification allows only `random` and `datetime` imports. `main.py` imports only `datetime`; all other behavior uses built-in Python features.

## 9. Testing checklist

1. Run `python main.py` and check that all demonstration sections execute.
2. Test the parser with a delimiter inside quotes, a doubled quote, an empty field, and a trailing delimiter.
3. Create two filters with different thresholds and confirm their audit counts remain independent.
4. Confirm each positional lambda tests the correct index.
5. Save `id(queue)`, call `clean_transaction_queue(queue)`, and confirm the ID is unchanged.
6. Test account settlement with both successful and failing accounts; verify the batch continues after a failure.
7. Create a backup of `accounts.db` before testing an in-place record update.
8. Check `ledger.txt` and `corrupted.log` after file-audit tests.

## 10. Limitations

- This is an educational command-line project, not a real banking application.
- It does not provide user login, permissions, encryption, concurrency protection, or transaction rollback.
- Account records are stored as plain text.
- The demo account balance used by the CLI is separate from the object-oriented account examples and database file.
