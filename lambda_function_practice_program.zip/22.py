# Program 22
# Question: Given a list of numbers, use lambda and filter() to find numbers greater than the average.
# Comments explain the main steps.

nums = [10, 20, 30, 40]
avg = sum(nums) / len(nums)
print(list(filter(lambda x: x > avg, nums)))
