# Program 21
# Question: Given a list of numbers, use lambda and filter() to find the second-largest number.
# Comments explain the main steps.

nums = [4, 9, 1, 9, 7]
unique = sorted(set(nums))
print(unique[-2] if len(unique) >= 2 else "Not enough unique numbers")
