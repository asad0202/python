# Program 27
# Question: Given a list of dictionaries containing student information, use lambda to sort students according to marks.
# Comments explain the main steps.

students = [{"name":"Asha", "marks":80}, {"name":"Raj", "marks":95}]
print(sorted(students, key=lambda x: x["marks"]))
