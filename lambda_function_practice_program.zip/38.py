# Program 38
# Question: Given a list of numbers, use filter() to remove duplicate values and sorted() to arrange the remaining numbers.
# Comments explain the main steps.

nums = [3, 1, 3, 2, 1, 5]
print(sorted(set(nums)))
