# Program 19
# Question: Use lambda with filter() to find strings containing the character 'a'.
# Comments explain the main steps.

words = ["cat", "apple", "sky", "grape"]
print(list(filter(lambda s: "a" in s.lower(), words)))
