# Program 14
# Question: Use lambda with filter() to find numbers less than 25.
# Comments explain the main steps.

nums = [10, 20, 30, 40]
print(list(filter(lambda x: x < 25, nums)))
