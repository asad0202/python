# Program 20
# Question: Use lambda with filter() to remove all empty strings from a list. Placement-Level Lambda Programs
# Comments explain the main steps.

words = ["", "hello", "", "python"]
print(list(filter(lambda s: s != "", words)))
