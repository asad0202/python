# Program 1
# Question: Create a lambda function to find the square of a number.
# Comments explain the main steps.

square = lambda x: x * x
print(square(5))
