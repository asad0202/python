# Program 2
# Question: Create a lambda function to find the cube of a number.
# Comments explain the main steps.

cube = lambda x: x ** 3
print(cube(3))
