# Program 35
# Question: Given a list of salaries, use filter() to select salaries above ₹40,000 and map() to increase them by 10%.
# Comments explain the main steps.

salaries = [30000, 45000, 60000]
print(list(map(lambda x: round(x*1.10, 2), filter(lambda x: x > 40000, salaries))))
