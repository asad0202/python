# Program 36
# Question: Given a list of student marks, use filter() to select students who passed and sorted() to arrange them by marks.
# Comments explain the main steps.

students = [("Asha", 75), ("Raj", 35), ("Mina", 88)]
passed = filter(lambda s: s[1] >= 40, students)
print(sorted(passed, key=lambda s: s[1]))
