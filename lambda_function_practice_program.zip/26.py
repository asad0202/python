# Program 26
# Question: Given a list of tuples containing (name, salary), use lambda to sort employees according to salary.
# Comments explain the main steps.

employees = [("Asha", 40000), ("Raj", 60000)]
print(sorted(employees, key=lambda x: x[1]))
