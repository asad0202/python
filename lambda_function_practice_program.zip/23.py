# Program 23
# Question: Given a list of numbers, use lambda with sorted() to arrange numbers in descending order.
# Comments explain the main steps.

nums = [4, 1, 9, 2]
print(sorted(nums, key=lambda x: x, reverse=True))
