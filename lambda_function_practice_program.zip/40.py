# Program 40
# Question: Given student records (name, marks), use lambda to create a ranking system and display students from highest to lowest marks.
# Comments explain the main steps.

students = [("Asha", 80), ("Raj", 95), ("Mina", 88)]
ranking = sorted(students, key=lambda s: s[1], reverse=True)
for rank, (name, marks) in enumerate(ranking, start=1):
    print(rank, name, marks)
