# Program 18
# Question: Use lambda with filter() to find names that start with the letter 'A'.
# Comments explain the main steps.

names = ["Aman", "Ravi", "Anu", "Zara"]
print(list(filter(lambda s: s.startswith("A"), names)))
