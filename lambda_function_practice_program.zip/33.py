# Program 33
# Question: Use lambda, map() and filter() together to find the squares of only even numbers.
# Comments explain the main steps.

nums = [1, 2, 3, 4, 5, 6]
print(list(map(lambda x: x*x, filter(lambda x: x % 2 == 0, nums))))
