# Program 28
# Question: Given a list of dictionaries containing employee information, use lambda to find employees whose salary is greater than ₹50,000.
# Comments explain the main steps.

employees = [{"name":"Asha", "salary":45000}, {"name":"Raj", "salary":60000}]
print(list(filter(lambda x: x["salary"] > 50000, employees)))
