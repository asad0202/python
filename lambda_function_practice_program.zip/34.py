# Program 34
# Question: Use lambda, map() and filter() together to find the cubes of numbers divisible by 3.
# Comments explain the main steps.

nums = [1, 2, 3, 4, 6, 7, 9]
print(list(map(lambda x: x**3, filter(lambda x: x % 3 == 0, nums))))
