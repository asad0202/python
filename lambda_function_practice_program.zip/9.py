# Program 9
# Question: Use lambda with map() to convert a list of strings into uppercase.
# Comments explain the main steps.

words = ["python", "hello"]
print(list(map(lambda s: s.upper(), words)))
