# Program 15
# Question: Use lambda with filter() to find numbers divisible by 3 and 5.
# Comments explain the main steps.

nums = [3, 5, 9, 15, 30]
print(list(filter(lambda x: x % 3 == 0 and x % 5 == 0, nums)))
