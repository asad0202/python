# Program 25
# Question: Given a list of tuples containing (name, marks), use lambda to sort students according to marks.
# Comments explain the main steps.

students = [("Asha", 80), ("Raj", 95), ("Mina", 88)]
print(sorted(students, key=lambda x: x[1]))
