# Program 5
# Question: Use lambda with map() to double every element in a list.
# Comments explain the main steps.

nums = [1, 2, 3, 4]
# map applies the lambda to every item
print(list(map(lambda x: x * 2, nums)))
