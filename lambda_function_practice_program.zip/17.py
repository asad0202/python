# Program 17
# Question: Use lambda with filter() to find words having more than 5 characters.
# Comments explain the main steps.

words = ["apple", "banana", "cat", "orange"]
print(list(filter(lambda s: len(s) > 5, words)))
