# Program 4
# Question: Create a lambda function to check whether a number is even or odd.
# Comments explain the main steps.

even_odd = lambda n: "Even" if n % 2 == 0 else "Odd"
print(even_odd(7))
