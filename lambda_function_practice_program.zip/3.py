# Program 3
# Question: Create a lambda function to find the maximum of two numbers.
# Comments explain the main steps.

maximum = lambda a, b: a if a > b else b
print(maximum(10, 20))
