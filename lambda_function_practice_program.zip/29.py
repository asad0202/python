# Program 29
# Question: Given a list of student records (name, marks), use lambda to find the top 3 students.
# Comments explain the main steps.

students = [("Asha", 80), ("Raj", 95), ("Mina", 88), ("Dev", 70)]
print(sorted(students, key=lambda x: x[1], reverse=True)[:3])
