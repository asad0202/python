# Program 7
# Question: Use lambda with map() to find the cube of every number in a list.
# Comments explain the main steps.

nums = [1, 2, 3, 4]
print(list(map(lambda x: x ** 3, nums)))
