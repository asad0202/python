# Program 16
# Question: Use lambda with filter() to find all positive numbers from a list.
# Comments explain the main steps.

nums = [-2, 0, 4, 7, -1]
print(list(filter(lambda x: x > 0, nums)))
