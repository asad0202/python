# Program 8
# Question: Use lambda with map() to add 5 to every number in a list.
# Comments explain the main steps.

nums = [1, 2, 3]
print(list(map(lambda x: x + 5, nums)))
