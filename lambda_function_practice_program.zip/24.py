# Program 24
# Question: Given a list of names, use lambda with sorted() to sort names according to their length.
# Comments explain the main steps.

names = ["Sam", "Christopher", "Asha"]
print(sorted(names, key=lambda s: len(s)))
