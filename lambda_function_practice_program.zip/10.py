# Program 10
# Question: Use lambda with map() to find the length of every string in a list. Lambda with filter()
# Comments explain the main steps.

words = ["cat", "python"]
print(list(map(lambda s: len(s), words)))
