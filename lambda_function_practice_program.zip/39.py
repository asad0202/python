# Program 39
# Question: Given employee records (name, department, salary), use lambda to find employees from the IT department with salary above ₹50,000.
# Comments explain the main steps.

employees = [("Asha", "HR", 60000), ("Raj", "IT", 55000), ("Mina", "IT", 45000)]
print(list(filter(lambda e: e[1] == "IT" and e[2] > 50000, employees)))
