# Program 13
# Question: Use lambda with filter() to find numbers greater than 50.
# Comments explain the main steps.

nums = [10, 55, 70, 20]
print(list(filter(lambda x: x > 50, nums)))
