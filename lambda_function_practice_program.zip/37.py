# Program 37
# Question: Given a list of words, use filter() to select words starting with a vowel and sorted() to sort them by length.
# Comments explain the main steps.

words = ["apple", "sky", "orange", "umbrella", "cat"]
print(sorted(filter(lambda s: s[0].lower() in "aeiou", words), key=lambda s: len(s)))
