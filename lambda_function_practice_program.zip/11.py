# Program 11
# Question: Use lambda with filter() to find all even numbers from a list.
# Comments explain the main steps.

nums = [1, 2, 3, 4, 5, 6]
print(list(filter(lambda x: x % 2 == 0, nums)))
