# Program 31
# Question: Use lambda and reduce() to find the maximum number from a list.
# Comments explain the main steps.

from functools import reduce
nums = [4, 9, 2, 7]
print(reduce(lambda a, b: a if a > b else b, nums))
