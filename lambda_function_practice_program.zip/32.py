# Program 32
# Question: Use lambda and reduce() to find the product of all numbers in a list.
# Comments explain the main steps.

from functools import reduce
nums = [1, 2, 3, 4]
print(reduce(lambda a, b: a * b, nums, 1))
