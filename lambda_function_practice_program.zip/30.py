# Program 30
# Question: Given a list of numbers, use lambda with reduce() to find the sum of all numbers. Challenging Interview Programs
# Comments explain the main steps.

from functools import reduce
nums = [1, 2, 3, 4]
print(reduce(lambda a, b: a + b, nums, 0))
