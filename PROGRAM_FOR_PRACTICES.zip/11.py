# Program 11
# Question: If s2 is a part of s1 then print the 1st and last occurrences of it
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
