# Program 39
# Question: Remove a particular student from the list. (Take a name of student from the user.)
# Comments explain the main steps.

items = input("Enter initial items separated by spaces: ").split()
# Simple menu for common list operations
while True:
    print("1 Display  2 Append  3 Remove  4 Sort  5 Exit")
    choice = input("Choice: ")
    if choice == "1": print(items)
    elif choice == "2": items.append(input("Item to add: "))
    elif choice == "3":
        item = input("Item to remove: ")
        if item in items: items.remove(item)
        else: print("Item not found")
    elif choice == "4": items.sort()
    elif choice == "5": break
    else: print("Invalid choice")
