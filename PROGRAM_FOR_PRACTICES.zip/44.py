# Program 44
# Question: Create a list of employees (nested list) with their personal details like [name, age, salary, expertise] in a list. Ask the user to enter name and display the details of that employee. If the employee is not in the list, print error message.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
