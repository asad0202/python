# Program 64
# Question: ). Display the minimum and maximum marks of each subject in a separate dictionary object.
# Comments explain the main steps.

nums = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
if nums:
    print("Maximum:", max(nums))
    print("Minimum:", min(nums))
else:
    print("No values entered")
