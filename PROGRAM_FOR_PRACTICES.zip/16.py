# Program 16
# Question: Create a tuple for name say t1 (FirstName, MiddleName, LastName)
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
