# Program 3
# Question: Print the last 5 characters from the above given string
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
