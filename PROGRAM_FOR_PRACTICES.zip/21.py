# Program 21
# Question: Create a tuple of 5 fruits. Ask the user to input a fruit name and search that name in the given fruit tuple. Display suitable messages
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
target = input("Enter item to search: ")
if target in items:
    print("Found at index:", items.index(target))
else:
    print("Not found")
