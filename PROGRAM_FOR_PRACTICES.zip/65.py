# Program 65
# Question: Create a dictionary of 6 fruits (by taking user input) and store their buying and selling price as a tuple value. Display the fruit name whose buying price is less than its selling price and also the fruit name whose buying price is more than its selling price. Display the fruit that has earned no profit no loss.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
