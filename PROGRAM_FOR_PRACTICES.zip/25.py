# Program 25
# Question: Find an element in the nested tuple (t4) and print its position if found, otherwise print “Not found”
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
target = input("Enter item to search: ")
if target in items:
    print("Found at index:", items.index(target))
else:
    print("Not found")
