# Program 47
# Question: Create a list of 10 numbers and find the total of odd numbers and even numbers
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
