# Program 24
# Question: Create a nested tuple t4 of your (name, (hobbies), (friends), degree) by taking user inputs.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
