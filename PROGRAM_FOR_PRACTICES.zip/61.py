# Program 61
# Question: Create a dictionary from the above one, where key is rollno and value is (total of all subjects, percentage and grade ) a tuple of his result
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
