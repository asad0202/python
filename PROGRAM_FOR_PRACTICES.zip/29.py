# Program 29
# Question: Take a string as an input from the user. Find total number of vowels in it. (Hint: take a tuple of vowels)
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
