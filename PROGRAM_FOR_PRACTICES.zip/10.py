# Program 10
# Question: Take two strings as input s1 and s2 and check whether s2 is present in s1 or not.
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
target = input("Enter item to search: ")
if target in items:
    print("Found at index:", items.index(target))
else:
    print("Not found")
