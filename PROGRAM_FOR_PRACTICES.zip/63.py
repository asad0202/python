# Program 63
# Question: Take user input for roll no of 5 students and their coma separated marks of 6 subjects (out of
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
