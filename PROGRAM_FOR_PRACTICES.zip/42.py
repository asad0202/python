# Program 42
# Question: Create a list of alphabets and count total number of vowels in it.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
