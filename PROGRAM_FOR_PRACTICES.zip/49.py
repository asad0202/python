# Program 49
# Question: Create a list having mixed elements like string and integers. Print only integer elements from the list with and without using list comprehension DICTIONARY PROGRAM FOR PRACTICES
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
