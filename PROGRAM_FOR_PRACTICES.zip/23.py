# Program 23
# Question: Find the length of name of each city in the above tuple. With and without len() method
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
print("Length:", len(items))
