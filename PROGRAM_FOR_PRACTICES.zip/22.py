# Program 22
# Question: Create a tuple of cities of Gujarat by taking user input.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
