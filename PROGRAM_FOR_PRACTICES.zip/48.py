# Program 48
# Question: Put all the odd numbers in 1 list and even numbers in another list using list comprehension.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
