# Program 14
# Question: Check if any vowel present in the given string or not. If it is there then count each vowel and also display total number of vowels present in the given string
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
target = input("Enter item to search: ")
if target in items:
    print("Found at index:", items.index(target))
else:
    print("Not found")
