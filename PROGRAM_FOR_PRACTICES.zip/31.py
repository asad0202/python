# Program 31
# Question: Take a tuple of string elements and print all the strings in reverse. Eg. st=(‘Pen’, ‘Marker’, ‘Pencil’,’Eraser’,’Scale’) o/p – (‘neP’, ‘rekraM’, ‘licnep’, ‘resarE’, ‘elacS’) LIST PROGRAM FOR PRACTICES
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
# Slicing creates a reversed copy
print(items[::-1])
