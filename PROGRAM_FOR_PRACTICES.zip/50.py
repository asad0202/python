# Program 50
# Question: Create a dictionary of employees where empId will be the key and value will be the name of an employee
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
