# Program 9
# Question: Create a menu driven program for string manipulation a.​ Find the length of a string b.​ Print the string in upper case c.​ Print the string in lower case d.​ Print the string with initial capital e.​ Split the string
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
print("Length:", len(items))
