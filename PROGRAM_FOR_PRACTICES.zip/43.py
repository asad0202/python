# Program 43
# Question: Create a list of even numbers between 1 to 21 using range()
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
