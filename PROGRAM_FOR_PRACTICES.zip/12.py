# Program 12
# Question: If s2 is present in s1 then also count number of times it occurs in s1.
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
target = input("Enter item to search: ")
if target in items:
    print("Found at index:", items.index(target))
else:
    print("Not found")
