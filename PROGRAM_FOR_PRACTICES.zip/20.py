# Program 20
# Question: Take an input number and find whether that is present as an element in the tuple t3 or not.
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
target = input("Enter item to search: ")
if target in items:
    print("Found at index:", items.index(target))
else:
    print("Not found")
