# Program 2
# Question: Print a part of the above string “very much” using the slice operator.
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
