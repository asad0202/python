# Program 46
# Question: Display the students from L1 list, whose name contains the character ‘a’.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
