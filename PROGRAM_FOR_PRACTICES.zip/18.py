# Program 18
# Question: Make a total of all the marks and print it. (with and without using sum() method)
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
