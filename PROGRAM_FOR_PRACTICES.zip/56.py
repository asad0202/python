# Program 56
# Question: Change the name of the employee of empID taken by the user
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
