# Program 37
# Question: If the student’s name is present in the list, print total number of same name students in the list L1 and display the position of 1st occurrence of that name
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
target = input("Enter item to search: ")
if target in items:
    print("Found at index:", items.index(target))
else:
    print("Not found")
