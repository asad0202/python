# Program 1
# Question: Print multiple lines using single print statement. as – I like “Python Programming” very much It is my favorite subject
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
