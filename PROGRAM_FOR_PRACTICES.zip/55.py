# Program 55
# Question: If an empID is there in the dictionary then display the name of that employee or if not available then add an ID and Name of the employee in the dictionary
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
