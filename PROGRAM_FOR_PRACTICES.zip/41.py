# Program 41
# Question: Create a list of 10 numbers and find the maximum and minimum numbers from it.
# Comments explain the main steps.

nums = [12, 5, 30, 8, 17, 2, 44, 9, 21, 6]
# Track highest and lowest values
highest = lowest = nums[0]
for n in nums[1:]:
    if n > highest: highest = n
    if n < lowest: lowest = n
print("Maximum:", highest)
print("Minimum:", lowest)
