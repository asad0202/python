# Program 62
# Question: Display the rollno who has scored highest marks (total)
# Comments explain the main steps.

nums = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
if nums:
    print("Maximum:", max(nums))
    print("Minimum:", min(nums))
else:
    print("No values entered")
