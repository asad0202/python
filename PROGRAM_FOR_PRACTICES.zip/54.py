# Program 54
# Question: Take an empId from the user and check if that employee is there in the dictionary or not.
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
