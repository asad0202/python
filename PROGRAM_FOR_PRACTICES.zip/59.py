# Program 59
# Question: Display the youngest student from the above dictionary.
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
