# Program 45
# Question: Create a list by taking any 5 inputs from the user.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
