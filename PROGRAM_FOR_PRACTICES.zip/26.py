# Program 26
# Question: Take a tuple of 10 integer numbers and segregate odd and even numbers in 2 different tuples.
# Comments explain the main steps.

nums = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
even = [x for x in nums if x % 2 == 0]
odd = [x for x in nums if x % 2 != 0]
print("Even:", even)
print("Odd:", odd)
