# Program 19
# Question: Make a tuple t3 having 2 elements as t1 and t2 (tuples created above) – It is called a nested tuple
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
