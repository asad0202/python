# Program 35
# Question: Display all the students in the sorted order
# Comments explain the main steps.

items = input("Enter numbers separated by spaces: ").split()
nums = [int(x) for x in items]
print("Ascending:", sorted(nums))
print("Descending:", sorted(nums, reverse=True))
