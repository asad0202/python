# Program 36
# Question: Check a particular student’s name is present in the list or not
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
target = input("Enter item to search: ")
if target in items:
    print("Found at index:", items.index(target))
else:
    print("Not found")
