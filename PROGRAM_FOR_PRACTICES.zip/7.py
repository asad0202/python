# Program 7
# Question: Take a number and a string from the user and repeat the string for that many times.
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
