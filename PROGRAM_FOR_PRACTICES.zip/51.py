# Program 51
# Question: Display how many employees are there in the dictionary.
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
