# Program 27
# Question: Take a tuple input and print all the elements of it in reverse order
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
# Slicing creates a reversed copy
print(items[::-1])
