# Program 17
# Question: Create a tuple say t2 for marks of 5 subjects
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
