# Program 60
# Question: Create a dictionary of students having rollno of the student is as key and value is a list of marks obtained by that student in 5 subjects
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
