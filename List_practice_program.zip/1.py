# Program 1
# Question: Write a program to create a list of 10 numbers and print it.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
