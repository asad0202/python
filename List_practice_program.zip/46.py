# Program 46
# Question: Write a program to merge two lists, remove duplicate elements, sort the final list, and display it in ascending and descending order.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
unique = []
# Keep only the first occurrence of each item
for item in items:
    if item not in unique:
        unique.append(item)
print("Unique values:", unique)
