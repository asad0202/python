# Program 57
# Question: Write a program to find the second largest and second smallest element in a list without using built-in sorting.
# Comments explain the main steps.

items = input("Enter numbers separated by spaces: ").split()
nums = [int(x) for x in items]
print("Ascending:", sorted(nums))
print("Descending:", sorted(nums, reverse=True))
