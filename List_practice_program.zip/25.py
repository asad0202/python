# Program 25
# Question: Write a program to Find the frequency of each element (build a dictionary).
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
frequency = {}
# Count each value using a dictionary
for item in items:
    frequency[item] = frequency.get(item, 0) + 1
print(frequency)
