# Program 43
# Question: Write a program to Create a list of 10 student marks. Perform insertion, deletion, updating, sorting, reversing, and display the highest, lowest, and average marks.
# Comments explain the main steps.

nums = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
if nums:
    print("Maximum:", max(nums))
    print("Minimum:", min(nums))
else:
    print("No values entered")
