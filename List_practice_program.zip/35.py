# Program 35
# Question: Write a program to Filter out all vowels from a list of characters.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
