# Program 58
# Question: Write a program to Create a list of numbers and replace every negative number with zero.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
