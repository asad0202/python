# Program 54
# Question: Accept two lists of equal size and create a third list containing the sum of corresponding elements.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
