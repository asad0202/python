# Program 61
# Question: Write a program to Accept a list and check whether it is a palindrome without converting it into a string.
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
# A palindrome reads the same forward and backward
print("Palindrome" if items == items[::-1] else "Not palindrome")
