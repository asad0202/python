# Program 44
# Question: Write a program to Accept a list of integers from the user. Remove all duplicate elements without using a set and display the unique list.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
unique = []
# Keep only the first occurrence of each item
for item in items:
    if item not in unique:
        unique.append(item)
print("Unique values:", unique)
