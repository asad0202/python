# Program 40
# Question: Write a program to Extract words longer than 5 letters from a sentence.
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
