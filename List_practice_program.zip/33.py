# Program 33
# Question: Write a program to Group elements by a condition (e.g., odd/even, length of strings).
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
print("Length:", len(items))
