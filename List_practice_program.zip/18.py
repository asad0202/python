# Program 18
# Question: Write a program to Flatten a nested list (e.g., [[1,2],[3,4]] → [1,2,3,4]).
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
