# Program 51
# Question: Write a menu-driven program to perform all list operations: o​ Append o​ Insert o​ Extend o​ Remove o​ Pop o​ Sort o​ Reverse o​ Count o​ Index o​ Copy o​ Clear o​ Display
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
# Slicing creates a reversed copy
print(items[::-1])
