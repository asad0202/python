# Program 16
# Question: Write a program to Find the second largest/smallest number in a list.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
