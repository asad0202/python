# Program 15
# Question: Write a program to Find the average of numbers in a list.
# Comments explain the main steps.

nums = [float(x) for x in input("Enter numbers separated by spaces: ").split()]
# Average is total divided by number of values
print("Average:", sum(nums) / len(nums) if nums else 0)
