# Program 56
# Question: Write a program to Accept a list of integers and rotate the list by k positions (left and right).
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
