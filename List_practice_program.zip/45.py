# Program 45
# Question: Write a program to Create a shopping list. Implement a menu-driven program to add, remove, search, update, sort, and display items.
# Comments explain the main steps.

items = input("Enter numbers separated by spaces: ").split()
nums = [int(x) for x in items]
print("Ascending:", sorted(nums))
print("Descending:", sorted(nums, reverse=True))
