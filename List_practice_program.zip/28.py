# Program 28
# Question: Write a program to Find the index of the first/last occurrence of an element.
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
