# Program 13
# Question: Write a program to Remove duplicates from a list.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
unique = []
# Keep only the first occurrence of each item
for item in items:
    if item not in unique:
        unique.append(item)
print("Unique values:", unique)
