# Program 41
# Question: Write a program to Create a multiplication table (list of lists) using comprehension.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
