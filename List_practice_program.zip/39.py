# Program 39
# Question: Write a program to Convert a list of strings to uppercase using comprehension.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
