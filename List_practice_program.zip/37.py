# Program 37
# Question: Write a program to Flatten a 2D list using a nested comprehension.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
