# Program 66
# Question: Write a program to Accept a list of marks and assign grades (A, B, C, D, F) using list comprehension.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
