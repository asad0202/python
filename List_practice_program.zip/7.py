# Program 7
# Question: Write a program to Count how many times a value appears in a list.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
