# Program 3
# Question: Write a program to Access the first, last, and middle elements.
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
