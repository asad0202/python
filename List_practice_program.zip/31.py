# Program 31
# Question: Write a program to Find the intersection, union, and difference of two lists.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
