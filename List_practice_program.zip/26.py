# Program 26
# Question: Write a program to Swap two elements at given positions.
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
