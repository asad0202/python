# Program 63
# Question: Write a program to Accept a list of integers and find all missing numbers between the minimum and maximum value
# Comments explain the main steps.

nums = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
if nums:
    print("Maximum:", max(nums))
    print("Minimum:", min(nums))
else:
    print("No values entered")
