# Program 34
# Question: Write a program to Create a list of squares of numbers 1–20 using a comprehension.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
