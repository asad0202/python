# Program 2
# Question: Write a program to Find the length of a list.
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
print("Length:", len(items))
