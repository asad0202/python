# Program 67
# Question: Write a program to Develop a menu-driven Student Record Management System using lists that supports: o​ Add student o​ Display all students o​ Search student o​ Update student o​ Delete stude o​ Sort by name o​ Sort by marks o​ Display topper o​ Display average marks o​ Exit
# Comments explain the main steps.

nums = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
if nums:
    print("Maximum:", max(nums))
    print("Minimum:", min(nums))
else:
    print("No values entered")
