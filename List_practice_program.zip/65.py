# Program 65
# Question: Write a program to Create a list using list comprehension for numbers from 1 to 100 and display: o​ Squares o​ Cubes o​ Even numbers o​ Odd numbers o​ Multiples of 5
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
