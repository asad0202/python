# Program 48
# Question: Write a program to Create a list of employee names. Search for a name, update it if found, otherwise add it to the list.
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
target = input("Enter item to search: ")
if target in items:
    print("Found at index:", items.index(target))
else:
    print("Not found")
