# Program 59
# Question: Write a program to Accept a list of numbers and separate them into positive, negative, and zero lists.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
