# Program 27
# Question: Write a program to Check if a list is a palindrome.
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
# A palindrome reads the same forward and backward
print("Palindrome" if items == items[::-1] else "Not palindrome")
