# Program 23
# Question: Write a program to Find all pairs in a list that sum to a target value.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
