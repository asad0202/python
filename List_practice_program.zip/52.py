# Program 52
# Question: Write a program to Accept a list of numbers and perform slicing operations to display: o​ First five elements o​ Last five elements o​ Alternate elements o​ Reverse list using slicing
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
# Slicing creates a reversed copy
print(items[::-1])
