# Program 36
# Question: Write a program to Create a list of tuples (number, square) for 1–10.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
