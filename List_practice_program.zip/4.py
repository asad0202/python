# Program 4
# Question: Write a program to Reverse a list without using reverse().
# Comments explain the main steps.

items = input("Enter items separated by spaces: ").split()
# Slicing creates a reversed copy
print(items[::-1])
