# Program 49
# Question: Write a program to Accept a sentence from the user, convert it into a list of words, count the occurrence of each word, and remove repeated words.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
frequency = {}
# Count each value using a dictionary
for item in items:
    frequency[item] = frequency.get(item, 0) + 1
print(frequency)
