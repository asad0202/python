# Program 12
# Question: Write a program to Copy a list (shallow copy) and show it doesn't affect the original.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
