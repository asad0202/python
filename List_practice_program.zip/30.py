# Program 30
# Question: Write a program to Interleave two lists (e.g., [1,3,5] and [2,4,6] → [1,2,3,4,5,6]).
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
