# Program 50
# Question: Write a program to Create a nested list containing student details (Roll No., Name, Marks). Display topper details and sort students according to marks.
# Comments explain the main steps.

nums = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
if nums:
    print("Maximum:", max(nums))
    print("Minimum:", min(nums))
else:
    print("No values entered")
