# Program 47
# Question: Write a program to Accept 15 numbers in a list. Separate them into even and odd lists and display their count, sum, maximum, and minimum values.
# Comments explain the main steps.

nums = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
even = [x for x in nums if x % 2 == 0]
odd = [x for x in nums if x % 2 != 0]
print("Even:", even)
print("Odd:", odd)
