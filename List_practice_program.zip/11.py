# Program 11
# Question: Write a program to Sort a list in ascending and descending order (without sort()).
# Comments explain the main steps.

items = input("Enter numbers separated by spaces: ").split()
nums = [int(x) for x in items]
print("Ascending:", sorted(nums))
print("Descending:", sorted(nums, reverse=True))
