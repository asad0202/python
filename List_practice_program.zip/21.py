# Program 21
# Question: Write a program to Rotate a list left/right by n positions.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
