# Program 14
# Question: Write a program to Convert a list of strings to a list of integers.
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
