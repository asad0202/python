# Program 42
# Question: Write a program to Filter numbers divisible by both 3 and 5.
# Comments explain the main steps.

# Example data; replace it with your own values as needed.
items = [1, 2, 3, 4, 5]
print(items)
