# Program 62
# Question: Write a program to Create a matrix using nested lists and perform: o​      Matrix addition o​      Matrix transpose o​      Sum of each row o​      Sum of each column
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
