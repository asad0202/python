# Program 55
# Question: Write a program to Create a list of strings. Display: o​ Longest string o​ Shortest string o​ Strings starting with a vowel o​ Strings ending with a consonant
# Comments explain the main steps.

items = input("Enter values separated by spaces: ").split()
# Display the entered values and basic information
print("List:", items)
print("Count:", len(items))
